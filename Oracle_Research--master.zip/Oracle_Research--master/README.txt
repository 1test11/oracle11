To provide guideline to understand the Oracle PL/SQL Units

I have 7+ years of experience in Oracle PL/SQL Development including Oracle DBA activities, Unix Shell/Perl Scripting and Cross-functional Coordination. 

I am currently working as the Senior Database Administrator (Oracle DBA & Oracle PL/SQL Developer) with the Government of Nepal,Ministry of Finance, Inland revenue Department deputed by Professional Computer System Pvt. Ltd. Lalitpur, Nepal. & I was 
lastly working as the Software Engineer (Oracle PL/SQL Developer - Database) with Verscend Technologies Pvt. Ltd., Kathmandu,Nepal. formerly known as Verisk Information Technologies Pvt. Ltd. This role required me to conduct scope analysis, business 
study, requirements study, design, development, testing and implementation, as well as rendering application enhancement support to the client; write fine-tuned PL/SQL scripts, Perl/Shell scripts as per the business requirement especially for 
Medical Intelligence Software; contribute to the development of physical & logical architecture diagrams including testing, troubleshooting & debugging of the software. 

Thank You,
Devesh Kumar Shrivastav
Senior Software Engineer - OCA/OCP in 9i,10g,11g and upgraded with 12c.
(Oracle DBA / Oracle PL/SQL Developer / Instructor(Online) -> Oracle PL/SQL,Unix Shell/Perl Scripting)
Mobile No: 00977-9841435006
Skype ID : unidev392
Email ID : unidev39@gmail.com
         : unidev39@hotmail.com
         : unidev39@yahoo.com 
